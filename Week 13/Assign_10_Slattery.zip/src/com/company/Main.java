package com.company;

public class Main {

    public static void main(String[] args) {
        CreateArray createArray = new CreateArray();
        createArray.createArray();
        WriteArrayFile.writeArrayFile(createArray.getUserInput());
        ReadArrayFile.readArrayFile();
        DevCalc devCalc = new DevCalc();
        devCalc.devCalc(ReadArrayFile.getArray());
    }
}
