import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DecimalConverter {
    private JPanel rootPanel;
    private JButton convertButton;
    private JTextField decimalTextField;
    private JLabel pleaseEnter;
    private JButton clearButton;
    private JTextField binaryTextField;
    private JLabel attemptCounter;
    private int attempt;

    public static void main(String[] args) {
        JFrame frame = new JFrame("DecimalConverter");
        frame.setContentPane(new DecimalConverter().rootPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public DecimalConverter() {
        convertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                attempt += 1;
                binaryTextField.setText(binaryReturn(decimalTextField));
                attemptCounter.setText("Attempt " + attempt);

            }
        });
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                attempt = 0;
                decimalTextField.setText("");
                binaryTextField.setText("");
                attemptCounter.setText("Attempt " + attempt);
            }
        });
    }

    private static String binaryReturn(JTextField decimal) {

        try
        {
            String dec = decimal.getText();
            int i = Integer.parseInt(dec);
            if(i < 0 || i > 255) {
                return "0 - 255 only.";
            }
            return Integer.toBinaryString(i);
        }
        catch (Exception e)
        {
            return "Whole numbers only.";
        }
    }
}


